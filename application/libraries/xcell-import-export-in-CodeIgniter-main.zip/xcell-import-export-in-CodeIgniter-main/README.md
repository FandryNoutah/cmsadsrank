"# xcell-import-export-in-CodeIgniter"

Excel,csv,xls,xlsx Import Export in CodeIgniter PHP MySQL
===========================================================

Import and Export xcell file in CodeIgniter
Downloaded PHPExcel will be into libraries folder

Excel extends PHPExcel
IOFactory extends PHPExcel_IOFactory

Write 2 class Excel & IOFactory  and extends from Core PHPExcel & PHPExcel

Load the library PHPExcel & excel
Now import
upload file 
load file
iterate sheet 
get row and column
and iterate it

get each value from each row
finally save into database

uploading from this form

now export
create an object PHPExcel
sheet index will be 0 at beginning
header column we will set according to need
read data from database
set data at setCellValueByColumnAndRow

write xcell with createWriter
and do output
The project is in github
downloaded link is in description box below



Youtube Tutorial : https://youtu.be/3jMujp8nUpw

Youtube Channel : https://www.youtube.com/channel/UC2Q4oWfoMQzi6AES8Vb2vQw?view_as=subscriber

Donate to Paypal : patabuz@gmail.com

https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=KHM59LRPNV3YY&source=url
