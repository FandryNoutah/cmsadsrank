

<style>
    #tableData td {
    text-align: center; /* Centre le texte horizontalement */
    vertical-align: middle; /* Centre le contenu verticalement */
}
.table-striped tbody tr:nth-of-type(2n+1) {
  background-color: white;
}
</style>
<?php if($this->session->flashdata('message-succes')): ?>
	<div class="alert alert-success alert-dismissible fade in mb-2" role="alert">
		<button type="button" class="close" data-dismiss="alert" aria-label="Close">
			<span aria-hidden="true">&times;</span>
		</button>
		<strong>Succès!</strong> <?php echo $this->session->flashdata("message-succes"); ?>
	</div>
<?php endif; ?>
<div id="messageBox" style="display: none; padding: 10px; margin-top: 20px; border-radius: 5px;"></div>

<div class="row">
	<div class="col-lg-12">
		<div class="card">

			<div class="card-header">
			    <h4 class="card-title">Listing client <span id="countItem"><?php  ?></span></h4>
			</div>
			
				
			<div class="card-body collapse in">
	    		<div class="card-block card-dashboard"></div>
				<div class="table-responsive" id="">
				<?php //foreach($current_user as $groups): ?>	
					
			<?php //var_dump($current_user->last_name);?>
		
		<?php //endforeach; ?>
        <div class="row">
                            <div class="col-lg-3">
                        <label for="filterEtat">Filtrer par état</label>
                        <select id="filterEtat" class="form-control">
                            <option value="">Tous</option>
                            <option value="0">Rapport à résilier</option>
                            <option value="1">Actif</option>
                            <option value="2">Résilié</option>
                        </select>
                    </div>
                    <div class="col-lg-3">
    <label for="filterMonth">Filtrer par Mois</label>
    <select id="filterMonth" class="form-control">
        <option value="">Sélectionner un Mois</option>
        <!-- Les mois seront ajoutés dynamiquement -->
    </select>
</div>

<div class="col-lg-3">
    <label for="filterYear">Filtrer par Année</label>
    <select id="filterYear" class="form-control">
        <option value="">Sélectionner une Année</option>
        <!-- Les années seront ajoutées dynamiquement -->
    </select>
</div>


            </div>
					
					<table id="tableData" class="tableData table table-hover mb-0 table-striped table-bordered dt-responsive nowrap" width="100%" cellspacing="0">
    <thead>
        <tr>
            <th>AM</th>
            <th>Nom du compte</th>
            
            <th>Date de création</th>
            <th>Contexte</th>
            <th>Rapport</th>
            <th>Rapport de conversions</th>
            <th>Rapport Conv. + CA</th>
            <th>Bilan</th>
            <th>Etat</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach($donnee as $C): ?>
        <tr>
            <td>
                <img src="<?php echo base_url(IMAGES_PATH . htmlspecialchars($C->am_photo_user)); ?>" alt="avatar" style="width: 40px;" class="avatar-image" data-id="<?php echo htmlspecialchars($C->idonnee); ?>" data-name=""
                data-rapport="<?php echo htmlspecialchars($C->rapport); ?>"
                data-rapport-conversions="<?php echo htmlspecialchars($C->rapport_conversions); ?>"
                data-rapport-conv-ca="<?php echo htmlspecialchars($C->rapport_conv_ca); ?>"
                data-bilan="<?php echo htmlspecialchars($C->bilan); ?>"
                data-remarque="<?php echo htmlspecialchars($C->remarque); ?>"
                data-resiliation="<?php echo htmlspecialchars($C->resiliation); ?>">
            </td>
            <td><?php echo htmlspecialchars($C->nom_client); ?></td>
          
            <td><?php echo htmlspecialchars($C->annonce); ?></td>
            <td>
            <?php if($C->annonce != 2022-00-00) : ?>
                    <?php echo anchor('Listing/contexte/' . $C->idonnee, 'Contexte', ['style' => 'color: black', 'data-edit' => $C->idonnee]); ?>
            <?php endif; ?>
            <?php if($C->annonce == 2022-00-00) : ?>
                    <a href="<?php echo $C->contexte; ?>" target="_blank">Contexte ancien</a>
            <?php endif; ?>

           

            </td>
            <td>
            <?php if($C->rapport != NULL): ?>      
            <a href="<?php echo $C->rapport; ?>" target="_blank">Rapport </a></td>
            <?php endif; ?>
            <td>
                <?php if($C->rapport_conversions != NULL): ?>    
                <a href="<?php echo $C->rapport_conversions; ?>" target="_blank">Conversions</a>
                <?php endif; ?>
            </td>
            <td><?php echo htmlspecialchars($C->rapport_conv_ca); ?></td>
            <td><?php echo htmlspecialchars($C->bilan); ?></td>
            <td class="etat" data-resiliation="<?php echo htmlspecialchars($C->resiliation); ?>">
    <?php if ($C->resiliation == 0): ?>
        <span style="padding-top: 10px; padding-bottom: 10px; padding-left: 25px; padding-right: 25px; background-color: #FFE177; color: #817E25!important; border-radius: 4px;">Rapport à résilier</span>
    <?php endif; ?>
    <?php if ($C->resiliation == 1): ?>
        <span style="padding-top: 10px; padding-bottom: 10px; padding-left: 25px; padding-right: 25px; background-color: #6CF5C2; color: #008767!important; border-radius: 4px;">Actif</span>
    <?php endif; ?>
    <?php if ($C->resiliation == 2): ?>
        <span style="padding-top: 10px; padding-bottom: 10px; padding-left: 25px; padding-right: 25px; background-color: #F56C93; color: #870055!important; border-radius: 4px;">Résilié</span>
    <?php endif; ?>
</td>


        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<!-- Modal for editing -->
<div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editModalLabel">Modifier les informations</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="editForm">
                    <input type="hidden" id="accountId" name="accountId">
                    <div class="mb-3">
                        <label for="rapport" class="form-label">Rapport</label>
                        <input type="text" class="form-control" id="rapport" name="rapport" required>
                    </div>
                    <div class="mb-3">
                        <label for="rapportConversions" class="form-label">Rapport de conversions</label>
                        <input type="text" class="form-control" id="rapportConversions" name="rapportConversions">
                    </div>
                    <div class="mb-3">
                        <label for="rapportConvCa" class="form-label">Rapport Conv. + CA</label>
                        <input type="text" class="form-control" id="rapportConvCa" name="rapportConvCa">
                    </div>
                    <div class="mb-3">
                        <label for="bilan" class="form-label">Bilan</label>
                        <input type="text" class="form-control" id="bilan" name="bilan">
                    </div>
                    <div class="mb-3">
                        <label for="remarque" class="form-label">Remarque</label>
                        <textarea class="form-control" id="remarque" name="remarque" rows="3"></textarea>
                    </div>
                    <div class="form-group">
                            <label for="resiliation">Etat</label>
                            <select name="resiliation" id="resiliation">
                                <option value="0">Rapport à résilié</option>
                                <option value="1">Actif</option>
                                <option value="2">Résilié</option>
                            </select>
                        </div>
                    <button type="submit" class="btn btn-primary">Sauvegarder</button>
                </form>
            </div>
        </div>
    </div>
</div>
</div>
        </div>
    </div>
</div>
</div>
<script>
  $(document).ready(function() {
    // Quand l'image est cliquée
    $('.avatar-image').on('click', function() {
        var idonnee = $(this).data('id');
        var accountName = $(this).data('name');
        var rapport = $(this).data('rapport');
        var rapportConversions = $(this).data('rapport-conversions');
        var rapportConvCa = $(this).data('rapport-conv-ca');
        var bilan = $(this).data('bilan');
        var remarque = $(this).data('remarque');
        var resiliation = $(this).data('resiliation');

        // Remplir les champs du modal avec les informations de l'image cliquée
        $('#accountId').val(idonnee);
        $('#rapport').val(rapport);
        $('#rapportConversions').val(rapportConversions);
        $('#rapportConvCa').val(rapportConvCa);
        $('#bilan').val(bilan);
        $('#remarque').val(remarque);
        $('#resiliation').val(resiliation);

        // Ouvrir le modal
        $('#editModal').modal('show');
    });

    // Soumettre le formulaire d'édition
    $('#editForm').on('submit', function(e) {
        e.preventDefault();

        var idonnee = $('#accountId').val();
        var rapport = $('#rapport').val();
        var rapportConversions = $('#rapportConversions').val();
        var rapportConvCa = $('#rapportConvCa').val();
        var bilan = $('#bilan').val();
        var remarque = $('#remarque').val();
        var resiliation = $('#resiliation').val();

        // Envoi des données via AJAX
        $.ajax({
            url: '<?php echo site_url("Listing/uptates_information_rapport"); ?>', // URL de la méthode
            method: 'POST',
            data: {
                idonnee: idonnee,
                rapport: rapport,
                rapportConversions: rapportConversions,
                rapportConvCa: rapportConvCa,
                bilan: bilan,
                remarque: remarque,
                resiliation: resiliation
            },
            success: function(response) {
                var responseData = JSON.parse(response);

                // Afficher le message dans le messageBox
                $('#messageBox').show();
                if (responseData.status === 'success') {
                    $('#messageBox').text(responseData.message).css('background-color', 'green').css('color', 'white');
                    // Rafraîchir la page après une mise à jour réussie
                    location.reload(); // Rafraîchir la page
                } else {
                    $('#messageBox').text(responseData.message).css('background-color', 'red').css('color', 'white');
                }
            },
            error: function() {
                $('#messageBox').show().text('Erreur de communication avec le serveur.').css('background-color', 'red').css('color', 'white');
            }
        });
    });
});


</script>

					<script type="text/javascript">
$(document).ready(function() {
    var $dataTable = $('#tableData').DataTable({
        destroy: true,
        responsive: false,
        paging: false,  // Pas de pagination, afficher tout
        searching: true,  // Recherche activée
        scrollX: true,
        language: {
            "search": "Rechercher:",
            "info": ""  // Désactiver l'affichage de l'information
        },
        order: [[1, 'asc']],  // Tri initial
        initComplete: function() {
            var api = this.api();

            // Dynamically populate months in filterMonth
            var months = [
                "Janvier", "Février", "Mars", "Avril", "Mai", "Juin", 
                "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"
            ];

            months.forEach(function(month, index) {
                $('#filterMonth').append($('<option>', {
                    value: (index + 1).toString().padStart(2, '0'),  // Format MM
                    text: month
                }));
            });

            // Dynamically populate years in filterYear (2023-2030)
            for (var year = 2022; year <= 2030; year++) {
                $('#filterYear').append($('<option>', {
                    value: year,
                    text: year
                }));
            }

            // Filtrer par État, Mois et Année combinés
            $('#filterEtat, #filterMonth, #filterYear').on('change', function() {
                var selectedEtat = $('#filterEtat').val();  // État sélectionné
                var selectedMonth = $('#filterMonth').val();  // Mois sélectionné
                var selectedYear = $('#filterYear').val();    // Année sélectionnée

                api.rows().every(function() {
                    var row = this.node();
                    var dateCreation = $(row).find('td').eq(2).text();  // Récupérer la colonne "Date de création"
                    var rowDate = new Date(dateCreation); // Créer un objet Date

                    // Extraire le mois et l'année de la date
                    var rowMonth = (rowDate.getMonth() + 1).toString().padStart(2, '0');  // Mois avec 2 chiffres
                    var rowYear = rowDate.getFullYear();
                    var rowEtatText = $(row).find('.etat').text().trim();  // Extraire le texte de l'état

                    // Définir un état correspondance basé sur les options
                    var isEtatMatch = true;
                    if (selectedEtat) {
                        if (selectedEtat == "0" && rowEtatText !== "Rapport à résilier") {
                            isEtatMatch = false;
                        } else if (selectedEtat == "1" && rowEtatText !== "Actif") {
                            isEtatMatch = false;
                        } else if (selectedEtat == "2" && rowEtatText !== "Résilié") {
                            isEtatMatch = false;
                        }
                    }

                    // Vérifier si les mois et années correspondent
                    var isMonthMatch = true;
                    if (selectedMonth && rowMonth !== selectedMonth) {
                        isMonthMatch = false;
                    }

                    var isYearMatch = true;
                    if (selectedYear && rowYear != selectedYear) { // Comparer strictement les années
                        isYearMatch = false;
                    }

                    // Afficher ou cacher la ligne selon les filtres
                    if (isEtatMatch && isMonthMatch && isYearMatch) {
                        $(row).show();  // Afficher si tous les filtres sont valides
                    } else {
                        $(row).hide();  // Cacher sinon
                    }
                });
            });
        }
    });
});

</script>

