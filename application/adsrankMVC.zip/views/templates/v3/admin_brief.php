<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <title>Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:500,400,600|Manrope:400,500,700,800" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(CSS_PATH."/Amdin_brief_css.css") ?>">
  </head>
  <style>
 


</style>
  <body>
  <div class="row">
<div class="col-md-12" style="text-align: right">
<?php foreach($donnees as $D): ?>
                    <?php if($D['information_client'] != NULL): ?>           
                        <?php echo anchor("Googleads/information_client/".$D['idclients'], 
                        '<h6 style="width: 180px; height: 41px; background-color: #4EA5FE; color: white; border-radius: 20px;" class="btn">Modifier information</h6><i class="button"></i>', 
                        'data-edit="'.$D['idonnee'].'"'); ?>
                        <?php echo anchor("Googleads/campagne/".$D['idclients'], 
                        '<h6 style="width: 180px; height: 41px; margin-left: 10px; background-color: white; color: black; border-width: 2px; border-color: black; border-radius: 20px;" class="btn">Suivant</h6><i class="button"></i>', 
                        'data-edit="'.$D['idonnee'].'"'); ?>
                    <?php endif; ?>   
                <?php endforeach; ?> 
</div>
</div> 
<button id="toggleButton" onclick="toggleDetails()">👁️</button>  
<div class="row">

    <div class="details" style="display: block; ">
        <div class="col-md-3" style="width: 290px; padding-bottom: 50px; padding-top: 25px; margin-right: 10px; border-radius: 5px; background-color: white; height: 800px">
            <?php foreach($idinitiative as $D): ?> 
                <span>    
                    <img width="120" style="text-align: center; margin-bottom: 50px; margin-left: 70px;" src="<?php echo base_url(IMAGES_PATH.$D['photo_users']) ?>" alt="avatar"> 
                </span>
                <h5 style="text-align: center">Source</h5>
                <div class="row">
                    <div class="col-md-4" style="width: 120px; text-align: right">
                    
                        <span>Commercial :</span></br>
                         <span>AM :</span></br>
                    </div> 
                    <div class="col-md-4" style=" width: 190px;text-align: left; margin-left: -20px;">
                        <span style="color: black;"><?php echo $D['first_name']; ?></span></br>
                        <span style="color: black;"><?php echo $idam[0]['first_name']; ?></span></br>
                    
                    </div>
      
           </div>
           <hr style="border: 1px solid rgba(90, 96, 107, 1); width: 50%; margin: 20px auto;">

           <h5 style="text-align: center">Information client</h5>
           <div class="row">
                    <div class="col-md-3" style="width: 120px; text-align: right">
                         <span>Client :</span></br>
                         <span>Site internet :</span></br>
                         <span>Nom :</span></br>
                        <span>Prénom :</span></br>
                        <span>Email :</span></br>
                        <span>Téléphone :</span></br></br>   
                    </div> 
                    <div class="col-md-5" style=" width: 190px;text-align: left; margin-left: -20px;">
                    <?php foreach($client as $Cl): ?> 
                                <span style="color: black !important;"><?php echo $Cl['nom_client']; ?></span></br>
                                <span style="color: black !important;">
                                <a href="<?php 
                                            // Vérifier si l'URL commence par http:// ou https://
                                            $url = $Cl['site_client'];
                                            if (!filter_var($url, FILTER_VALIDATE_URL)) {
                                                // Ajouter https:// si l'URL est mal formée ou relative
                                                $url = 'https://' . $url;
                                            }
                                            echo $url; 
                                        ?>" 
                                        style="color: #373a3c" target="_blank">
                                        Lien
                                        </a>  
                                </span></br>
                                <span style="color: black !important;"><?php echo $Cl['nom']; ?></span></br>
                                <span style="color: black !important;"><?php echo $Cl['prenom']; ?></span></br>
                                <span style="color: black !important;"><a href="mailto:<?php echo $Cl['email_client']; ?>" >Lien</a></span></br>
                                <span style="color: black !important;"><?php echo $Cl['numero_client']; ?></span></br>
                            <?php endforeach; ?>  
                </div>
      
           </div>
           <hr style="border: 1px solid rgba(90, 96, 107, 1); width: 50%; margin: 20px auto;">
            <div class="row" >
            
            <h5 style="text-align: center">Roadmap</h5>
                    <div class="col-md-5" style="width: 120px; text-align: right">
                         <span>Budget :</span></br>
                        <span>Anniversaire :</span></br>
                        <span>Mise en ligne :</span></br></br>

                        
                    </div> 
                    <div class="col-md-5" style=" width: 120px;text-align: left; margin-left: -20px;"> 
                        <?php foreach($donnees as $C): ?> 
                            <span style="color: black;"><?php echo $C['budget']; ?> €</span></br>
                            <span style="color: black;"><?php echo $C['mis_en_place_paiement']; ?></span></br>
                            <span style="color: black;"><?php echo $C['annonce']; ?></span></br>
                           
                            
                        <?php endforeach; ?>  
                    <?php endforeach; ?>  
                    </div>
                    
                     
                </div>
                <hr style="border: 1px solid rgba(90, 96, 107, 1); width: 50%; margin: 20px auto;">
                <div class="row" style="display: flex; justify-content: center;">
                <?php foreach($client as $Cl): ?> 
                <?php if (!empty($Cl['logo_client'])): ?>
                    <a href="<?php echo base_url($Cl['logo_client']); ?>" style="">
                        <img class="media-object" src="<?php echo base_url($Cl['logo_client']); ?>" 
                             title="<?php echo $Cl['logo_client']; ?>" alt="<?php echo $Cl['logo_client']; ?>" 
                             style="width: 150px; height: auto;  margin-top: 0px;" />
                    </a>
                <?php endif; ?>  
                <?php endforeach; ?> 
                </div>     
           </div>
           
      </div> 
    <div class="col-md-9" style="width: 80%;" >                                  
          <div class="details-card" style="background-color: white; margin-left: 0px;">
          <?php foreach($donnees as $D): ?>
            <div class="badges">
            <?php if($D['dejaclient'] == 1): ?>
              <span class="badge black" style="color: white! important;">Nouveau client</span>
              <?php endif; ?>
              <?php if($D['dejaclient'] == 0): ?>
              <span class="badge black" style="color: white! important;">Upsell</span>
              <?php endif; ?>
                <?php if($D['secteur_activite'] != NULL): ?>
              <span class="badge purple" style="color: white! important;"><?php echo $D['secteur_activite']; ?></span>
              <?php endif; ?>
              <?php endforeach; ?>
              
            </div>
      
            <?php foreach($client as $Cl): ?> 
                    <div style="margin-right: 10px; ">
                    <p class="client-name" style="color: black; font-size: 25px; text-decoration: underline;">
                    👁️ <?php echo $Cl['nom_client']; ?>
</p>

                    </div>
            <?php endforeach; ?>        
            
            <div style="text-align: center">   
                    <?php if($D['information_client'] == NULL): ?>
                        <?php foreach($client as $C): ?> 
                            <?php foreach($idam as $DA): ?>  
                                <h1 class="congratulation-message">
                                    Félicitation <?php echo $DA['first_name'] ?> ,</br> tu as en gestion l’entreprise <?php echo $C['nom_client'] ?>.
                                    À toi de jouer !!
                                </h1>
                            <?php endforeach; ?> 
                            <?php echo anchor("Googleads/information_client/".$D['idclients'], 
                            '<img width="150" src="'.base_url('assets/images/ico/drop.png').'" alt="WLB" title="WLB"/>', 
                            'data-edit="'.$D['idonnee'].'"'); ?>
                        <?php endforeach; ?>         
                        <p style="font-size: 25px;">Cliquer pour enregistrer le brief du client</p>
                    </div>  
                    <?php endif; ?>
                </div>  
                <?php if($D['information_client'] != NULL): ?>                    
            <section class="info-section">
              <h2 style="font-size: 16px;">Information client :</h2>
              <div class="info-content">
                <p style="font-size: 14px;"><?php echo nl2br($D['information_client']); ?><br>
                </p>
               
              </div>
            </section>
            <?php endif; ?>
            <?php if (!empty($D['contexte_client'])): ?>
            <section class="info-section">
              <h2 style="font-size: 16px;">Contexte client :</h2>
              <div class="info-content">
                <p style="font-size: 14px;"><?php echo $D['contexte_client']; ?><br>
                </p>
               
              </div>
            </section>
            <?php endif; ?>
            <?php if (!empty($D['tracking_gtm'])): ?>
            <section class="info-section">
              <h2 style="font-size: 16px;">Tracking GTM :</h2>
              <div class="info-content">
                <p style="font-size: 14px;"><?php echo nl2br($D['tracking_gtm']); ?><br>
                </p>
               
              </div>
            </section>
            <?php endif; ?>
            <?php if (!empty($D['commentaire'])): ?>    
            <section class="info-section">
              <h2 style="font-size: 16px;">Commentaire</h2>
              <div class="info-content">
                <p style="font-size: 14px;"><?php echo nl2br($D['commentaire']); ?></p>
              </div>
            </section>
            <?php endif; ?>
            <?php if (!empty($D['information_complementaire'])): ?>    
            <section class="info-section">
              <h2 style="font-size: 16px;">Information complémentaire :</h2>
              <div class="info-content">
                <p style="font-size: 14px;"><?php echo nl2br($D['information_complementaire']); ?></p>
              </div>
            </section>
          </div>
          <?php endif; ?>
        </div>
        </div> 
     
        </div>    </div>
      
      </main>
      <style>
    .status-new-client, .status-upsell {
        color: white; 
        background-color: black; 
        padding: 0 20px; 
        text-align: center; 
        border-radius: 4px;
    }
    .sector-info {
        margin-left: 25px; 
        color: white; 
        background-color: #6554E5; 
        text-align: center; 
        border-radius: 4px; 
        padding: 0 20px;
    }
    .congratulation-message {
        font-size: 72px; 
        text-align: center; 
        font-weight: bold;
    }

</style>


<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    function toggleDetails() {
        // Toggle the visibility of the details section
        $(".details").toggle();

        // Change the icon based on the visibility state
        var button = document.getElementById("toggleButton");
        if ($(".details").css("display") === "none") {
            button.innerHTML = "👁️"; // Croisillon pour fermer
        } else {
            button.innerHTML = "✖️"; // Œil pour ouvrir
        }
    }
</script>
  </body>
</html>