

<style>
    #tableData td {
    text-align: center; /* Centre le texte horizontalement */
    vertical-align: middle; /* Centre le contenu verticalement */
}
    /* Assurez-vous que Select2 prend toute la largeur du modal */
#idclients {
    width: 100%; /* Donne toute la largeur disponible */
}
.table-striped tbody tr:nth-of-type(2n+1) {
  background-color: white;
}
</style>


<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" rel="stylesheet" />

<!-- jQuery (Select2 dépend de jQuery) -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- Select2 JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>


<?php if($this->session->flashdata('message-succes')): ?>
	<div class="alert alert-success alert-dismissible fade in mb-2" role="alert">
		<button type="button" class="close" data-dismiss="alert" aria-label="Close">
			<span aria-hidden="true">&times;</span>
		</button>
		<strong>Succès!</strong> <?php echo $this->session->flashdata("message-succes"); ?>
	</div>
<?php endif; ?>
<div id="messageBox" style="display: none; padding: 10px; margin-top: 20px; border-radius: 5px;  background-color: #6CF5C2! important;"></div>

<div class="row">
	<div class="col-lg-12">
		<div class="card">

			<div class="card-header">
			    <h4 class="card-title">Upsell - Booster - Baisse<span id="countItem"><?php  ?></span></h4>
                
			</div>
			
				
			<div class="card-body collapse in">
	    		<div class="card-block card-dashboard"></div>
				<div class="table-responsive" id="">
				<?php //foreach($current_user as $groups): ?>	
					
			<?php //var_dump($current_user->last_name);?>
		
		<?php //endforeach; ?>
        <button  data-toggle="modal" data-target="#inlineNew" style=" width: 180px; height: 41px; background-color: #4EA5FE; color: white;  border-radius: 20px;">Nouveau</button>

				
					<table id="tableData" class="tableData table table-hover mb-0 table-striped table-bordered dt-responsive nowrap" width="100%" cellspacing="0">
    <thead>
        <tr>
            <th>Type</th>        
            <th>Date</th>
            <th>Client</th>
            <th>Demande</th>
            <th>Budget</th>
            <th>Date Upsell/baisse</th>
            <th>Date de création</th>
         
            
            <th>TM</th>
            <th>Informations</th>
            <th>Etat</th>
        </tr>
    </thead>
    <tbody>
        
    <?php 
    foreach ($upsell as $C): ?>
    <tr>
        <?php if($C->type_upsell == 0): ?>
        <td>Upsell - Booster</td>
        <?php endif; ?>
        <?php if($C->type_upsell == 1): ?>
        <td>Baisse</td>
        <?php endif; ?>
        <td><?php echo htmlspecialchars($C->date_upsell); ?></td>
        <td><?php echo htmlspecialchars($C->nom_client); ?></td>
        
        <!-- Affichage de la photo de l'Account Manager (am_upsell) -->
        <td>
            <img src="<?php echo base_url(IMAGES_PATH . htmlspecialchars($C->am_user_photo_users)); ?>" alt="AM Avatar" style="width: 40px;" class="avatar-image" 
            data-id="<?php echo htmlspecialchars($C->idonnee); ?>"
            data-budget_upsell="<?php echo htmlspecialchars($C->budget_upsell); ?>"     
            data-inforamtion_upsell="<?php echo htmlspecialchars($C->inforamtion_upsell); ?>"
            data-statut_upsell="<?php echo htmlspecialchars($C->statut_upsell); ?>"
            >
        </td>
        
        <!-- Affichage du budget si le type_upsell est 0 (augmenter le budget) -->
        <?php if ($C->type_upsell == 0):
            $budget_initiale = $C->budget; 
            $budget_demande =  $C->budget_upsell; 
            $budget_finale =  $budget_initiale + $budget_demande;   ?>
            <td> 
                Budget initiale: <?php echo $budget_initiale  ?> €</br>
                Budget à augmenter: <?php echo $budget_demande  ?> €</br>  
                Budget finale augmenter: <?php echo $budget_finale  ?> €</br>    
            </td>
        <?php endif; ?>

        <!-- Affichage du budget si le type_upsell est 1 (réduire le budget) -->
        <?php if ($C->type_upsell == 1):
            $budget_initiale = $C->budget; 
            $budget_demande =  $C->budget_upsell; 
            $budget_finale =  $budget_initiale - $budget_demande;   ?>  
            <td> 
                Budget initiale: <?php echo $budget_initiale  ?> €</br>
                Budget à réduire: <?php echo $budget_demande  ?> €</br>  
                Budget finale réduite: <?php echo $budget_finale  ?> €</br>   
            </td>    
        <?php endif; ?>

        <td><?php echo htmlspecialchars($C->date_upsell); ?></td>
        <td><?php echo htmlspecialchars($C->date_demande_upsell); ?></td>
        
        <!-- Affichage de la photo de l'utilisateur technique (technique_upsell) -->
        <td>
            <img src="<?php echo base_url(IMAGES_PATH . htmlspecialchars($C->tech_user_photo_users)); ?>" alt="Tech Avatar" style="width: 40px;" class="avatar-image" data-id="<?php echo htmlspecialchars($C->idonnee); ?>" >
        </td>

        <td><?php echo htmlspecialchars($C->inforamtion_upsell); ?> </td>
                                    <?php if($C->statut_upsell == 0 ): ?>
                                       <td> <span style="padding-top: 10px; padding-bottom: 10px; padding-left: 25px; padding-right: 25px; background-color: #FFE177; color: #817E25! important; border-radius: 4px;">Plannifier</span></td>     
                                    <?php endif; ?>
                                    <?php if($C->statut_upsell == 1 ): ?>
                                       <td> <span style="padding-top: 10px; padding-bottom: 10px; padding-left: 25px; padding-right: 25px; background-color: #64D5FE; color: #2079B0! important; border-radius: 4px;">Tâche programmer</span></td>     
                                    <?php endif; ?>
                                    <?php if($C->statut_upsell == 2): ?>
                                       <td> <span style="padding-top: 10px; padding-bottom: 10px; padding-left: 25px; padding-right: 25px; background-color: #6CF5C2; color: #008767! important; border-radius: 4px;">Tâche complète</span></td>     
                                    <?php endif; ?>

        
    </tr>
<?php endforeach; ?>

    </tbody>
</table>

<!-- Modal for editing -->
<div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editModalLabel">Modifier Upsell</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="editForm">
                    <input type="hidden" id="idonnee" name="idonnee">
                    <div class="mb-3">
                        <label for="inforamtion_upsell" class="form-label">Inforamtion upsell</label>
                        <input type="text" class="form-control" id="inforamtion_upsell" name="inforamtion_upsell" required>
                    </div>
                    <div class="mb-3">
                        <label for="budget_upsell" class="form-label">Budget</label>
                        <input type="text" class="form-control" id="budget_upsell" name="budget_upsell" required>
                    </div>
                    <div class="form-group">
                            <label for="exampleInputEmail1">Statut</label>
                            <select name="statut_upsell" id="statut_upsell">
                                <option value="0">Planifier</option>
                                <option value="1">Tâche programmer</option>
                                <option value="2">Tâche complète</option>
                            </select>
                        </div> 
                    <button type="submit" class="btn btn-primary" style=" height: 41px; background-color: #4EA5FE; color: white;  border-radius: 20px;">Sauvegarder</button>
                </form>
            </div>
        </div>
    </div>
</div>
</div>
    </div>
</div>
</div>
</div>
<script>
  $(document).ready(function() {
    // Quand l'image est cliquée
    $('.avatar-image').on('click', function() {
        var idonnee = $(this).data('id');
        var inforamtion_upsell = $(this).data('inforamtion_upsell');
        var budget_upsell = $(this).data('budget_upsell');
        var statut_upsell = $(this).data('statut_upsell');

        // Remplir les champs du modal avec les informations de l'image cliquée
        $('#idonnee').val(idonnee);
        $('#inforamtion_upsell').val(inforamtion_upsell);
        $('#budget_upsell').val(budget_upsell);
        $('#statut_upsell').val(statut_upsell);

        // Ouvrir le modal
        $('#editModal').modal('show');
    });

    // Soumettre le formulaire d'édition
    $('#editForm').on('submit', function(e) {
        e.preventDefault();

        var idonnee = $('#idonnee').val();
        var inforamtion_upsell = $('#inforamtion_upsell').val();
        var budget_upsell = $('#budget_upsell').val();
        var statut_upsell = $('#statut_upsell').val();

        // Envoi des données via AJAX
        $.ajax({
            url: '<?php echo site_url("Upsell/uptates_information"); ?>', // URL de la méthode
            method: 'POST',
            data: {
                idonnee: idonnee,
                inforamtion_upsell: inforamtion_upsell,
                budget_upsell: budget_upsell,
                statut_upsell: statut_upsell
            },
            success: function(response) {
                var responseData = JSON.parse(response);

                // Afficher le message dans le messageBox
                $('#messageBox').show();
                if (responseData.status === 'success') {
                    $('#messageBox').text(responseData.message).css('background-color', '#6CF5C2').css('color', 'black');
                    // Rafraîchir la page après une mise à jour réussie
                    location.reload(); // Rafraîchir la page
                } else {
                    $('#messageBox').text(responseData.message).css('background-color', 'red').css('color', 'white');
                }
            },
            error: function() {
                $('#messageBox').show().text('Erreur de communication avec le serveur.').css('background-color', 'red').css('color', 'white');
            }
        });
    });
});


</script>
<!-- Code du modal -->
<div class="modal fade text-xs-left" id="inlineNew" tabindex="-1" role="dialog" aria-labelledby="myModalLabel33" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content" style="padding: 20px;">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <h2 class="modal-title text-text-bold-300" id="myModalLabel33">Créer Upsell - Baisse</h2>
            </div>
            <div id="modal-form-new">
                <form action="<?php echo base_url("Upsell/creer_upsell") ?>" enctype="multipart/form-data" method="post" id="majCampagne">
                    <fieldset>
                        <br><br>
                        <input type="hidden" class="form-control"  name="demmande_upsell" value="<?php echo $current_user->id; ?><">

                        <div class="form-group">
                            <label for="exampleInputEmail1">Type</label>
                            <select name="type_upsell" id="product-choice">
                                <option value="0">Upsell</option>
                                <option value="1">Baisse</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="date_upsell1">Budget</label>
                            <input type="text" class="form-control"  name="budget_upsell" value="">
                        </div>
                        <div class="form-group">
    <label for="exampleInputEmail1">Client</label>
    <select name="client" id="idclients" style="width: 100%;">
        <!-- La liste déroulante sera remplie dynamiquement avec les clients -->
        <?php foreach ($donnee as $d): ?>
            <option value="<?php echo $d->idclients; ?>">
                <?php echo htmlspecialchars($d->nom_client); ?>
            </option>
        <?php endforeach; ?>
    </select>
</div>
<script>
$(document).ready(function() {
    $('#idclients').select2({
        placeholder: "Sélectionner un client", // Texte par défaut dans le champ de recherche
        allowClear: true // Permet de vider la sélection
    });
});

    </script>
                        <div class="form-group">
                            <label for="exampleInputEmail1">TM</label>
                            <select name="tm" id="product-choice">
                                    <option value="<?php echo $users[7]['id']; ?>">
                                        <?php echo $users[7]['first_name']; ?>
                                    </option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="date_upsell1">Date</label>
                            <input type="date" class="form-control" id="date_upsell1" name="date_upsell" value="">
                        </div>
                        <script>
                            // Cette fonction définit la date d'aujourd'hui comme valeur par défaut
                            document.getElementById('date_upsell1').value = new Date().toISOString().split('T')[0];
                        </script>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Date de demande</label>
                            <input type="date" class="form-control" id="exampleInputEmail1" name="date_demande_upsell">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Information</label>
                            <textarea class="form-control" id="exampleInputEmail1" name="inforamtion_upsell"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Statut</label>
                            <select name="statut_upsell" id="product-choice">
                                <option value="0">Planifier</option>
                                <option value="1">Tâche programmer</option>
                                <option value="2">Tâche complète</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary col-md-12" style=" height: 41px; background-color: #4EA5FE; color: white;  border-radius: 20px;">Ajouter</button>
                        </div>
                    </fieldset>
                </form>
            </div>
        </div>
    </div>
</div>



		</div>
					<script type="text/javascript">
$(function() {
    var $dataTable = $('#tableData').DataTable({
        destroy: true,
        responsive: false,
        paging: false,  // Pas de pagination, afficher tout
        searching: true,  // Recherche activée
        scrollX: true,
        language: {
            "search": "Rechercher:",
            "info": ""  // Désactiver l'affichage de l'information
        },
        order: [[1, 'asc']]
    });
});
</script>

