<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page avec popup</title>
    <style>
        body{
            background-color: white! important;
            color: black;
          
        }
        span{
            font-family: 'Manrope', sans-serif! important;
            
        }
        body label{
            font-size: 14px;
        }
.popup {
    display: none;
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background-color: white;
    padding: 20px;
    border: 2px solid #ccc;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    z-index: 1000;
    max-width: 1800px; /* Augmenter la largeur de la popup */
    width: 100%;
    text-align: center;
    max-height: 80vh; /* Limite la hauteur à 80% de la fenêtre visible */
    overflow: hidden;  /* Masque tout débordement à l'extérieur de la popup */
}

/* Contenu de la popup avec scroll si nécessaire */
.popup-content2 {
    max-height: 70vh; /* Limite la hauteur du contenu à 70% de la fenêtre */
    max-width: 150;
    overflow-y: auto;  /* Permet le défilement vertical si le contenu dépasse */
    margin-bottom: 20px;
}

/* Style pour le fond sombre derrière la popup */
.popup-overlay {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.7); /* Fond noir transparent */
    z-index: 999;
}




        /* Style pour le bouton */
        button {
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }

        button:hover {
            background-color: #0056b3;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
        }
        th {
            background-color: #F4F8FB;
            color: white;
            text-align: left;
        }
        td {
            background-color: #F4F8FB;
        }
        .header {
            font-weight: bold;
            color: #333;
            font-size: 18px;
            width: 35%;
        }
        .blue-cell {
            background-color: #4285f4;
            font-weight: bold;
            color: white;
            width: 10%;
        }
        .green-text {
            color: green;
        }
        .col {
            background-color: red;
        }
        /* Style for export button */
        .export-btn {
            margin: 20px 0;
            padding: 10px 20px;
            background-color: #4285f4;
            color: white;
            border: none;
            cursor: pointer;
        }
        /* Image style for logo */
        .logo-container {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }
        .logo-container img {
            width: 200px;
            padding-right: 20px;
        }
        .logo-container h1 {
            flex: 1;
            text-align: right;
        }
    </style>
</head>
<body>
<h3 style="font-size: 52px; text-align: center; margin-bottom: 20px;"><b><?php echo $current_user->first_name ?> , C’est parti pour</br> l’élaboration de la stratégie Search!!</h3></b>    

<div class="row">
        <div class="col-md-3" >
        
        <?php 
 
            foreach($client as $C): ?> 

            <?php foreach($donnees as $D): ?> 
            <?php if($D['dejaclient'] == 1): ?>
                            <p style="color: white; background-color: black; width: 120px; text-align: center; border-radius: 4px;">NOUVEAU CLIENT</p>
                        <?php elseif($D['dejaclient'] == 0): ?>
                            <p style="color: white; background-color: black; width: 120px; text-align: center; border-radius: 4px;">Upsell</p>
                        <?php endif; ?>
                        <?php if($D['secteur_activite'] != NULL): ?>
                            <p style="color: white; background-color: #6554E5; text-align: center; border-radius: 4px; width: 250px;"><?php echo $D['secteur_activite']; ?></p>
                        <?php endif; ?>
            <?php endforeach; ?>    
            <h3 style="color: #4EA5FC"><b><?php echo $C['nom_client'] ?>  (<?php echo $C['site_client'] ?>)</b></h3>
            <div class="row">
                <div class="col-md-5">
                <span style="">Site internet</span></br>
                <span>Date de mis en ligne</span></br>
         
                </div> 
          
                <div class="col-md-5" style="text-align: right;">
                    <?php foreach($donnees as $C): ?> 
                        <span style="color: black! important"><?php echo $C['mis_en_place_paiement']; ?></span></br>
                        <?php foreach($client as $Cl): ?> 
                            <span style="color: black! important"><?php echo $Cl['site_client']; ?></span></br>
                        <?php endforeach; ?>  
                    <?php endforeach; ?>  
                    <?php endforeach; ?>  
                </div>
            </div>
            </div>
            <div class="col-md-7">
            <img width="120" style="float: right; margin-bottom: 50px;" src="<?php echo base_url($client[0]['logo_client']) ?>" alt="avatar">
            </div>
        </div>
       

            <?php foreach($groupe as $D): ?>
							<h3 style="font-size: 20px;"></br>Campagne client : <a style="color: #37BC9B"> <?php echo $D['nom_groupe'] ?></a> </h3>

                            <?php endforeach; ?>
                            <table id="campaign-table">
    <thead>
        <tr>
            <th>Nom de campagne</th>
            <th style="width: 350px">Information campagne</th>
            <th style="width: 350px">Contexte groupe annonce</th>
            <th>Zone</th>
            <th>Objectif campagne</th>
            <th>URL</th>
            <th>Calendrier</th>
            <th>Appareils</th>
            <th>Budget</th>

        </tr>
    </thead>
    <tbody>
        <?php foreach($campagnes as $D): ?>
            <tr>
                    <td >
                        <?php echo $D['nom_campagne']; ?>
                    </td>
                    <td ><?php echo $D['information_campagne']; ?></td>
                    <td ><?php echo $D['contexte_groupes_annonces']; ?></td>
                    
                    <td ><?php echo $D['zones']; ?></td>
                    <td ><?php echo $D['objectif']; ?></td>
                    <td ><?php echo $D['url_site']; ?></td>
                    <td ><?php echo $D['date_campagne']; ?></td>
                    <td ><?php echo $D['appareil']; ?></td>
                    <td ><?php echo $D['repartition_budget']; ?> €</td>
               
            </tr> <!-- Fermer la ligne ici pour chaque campagne -->
        <?php endforeach; ?>
    </tbody>
</table>
            <div class="row" style="margin-top: 0px">
            <div class="col-md-4" style="margin-top: -50px">
							<form action="<?php echo site_url('Googleads/Ajoutgroupes'); ?>" method="POST" enctype="multipart/form-data">
                                    <div id="annonce-groups">
                                        <div class="annonce-group">
                                        <input type="hidden" name="idgroupe_annonce" class="form-control" value="<?php echo $D['idgroupe_annonce']; ?>" > <br>
                                        <input type="hidden" name="idcampagne" class="form-control" value="<?php echo $D['idcampagne']; ?>" > <br>
                                        <input type="hidden" name="idclients" class="form-control" value="<?php echo $D['idclients']; ?>" > <br>
                                        <input type="hidden" name="type_campagne" class="form-control" value="<?php echo $D['type_campagnes']; ?>" > <br>
                                            <label for="group-name">Nom du groupe :</label>
                                            <input type="text" name="nom_groupe" class="form-control" value="<?php echo $D['nom_groupe'] ?>" ><br>

                                            <label for="url">URL :</label>
                                                <input type="text" name="url" class="form-control" value="<?php echo $D['url_groupe_annonce']; ?>" ><br>

                                                <label for="keywords">Mot clé :</label>
                                                <textarea name="mot_cle" class="form-control" rows="10" cols="50"><?php echo $D['mot_cle']; ?></textarea><br>



                                                <label for="titre">Titre 1:</label>
<input type="text" name="titre1" class="form-control" value="<?php echo $D['titre1']; ?>"><br>

<label for="titre">Titre 2:</label>
<input type="text" name="titre2" class="form-control" value="<?php echo $D['titre2']; ?>"><br>

<label for="titre">Titre 3:</label>
<input type="text" name="titre3" class="form-control" value="<?php echo $D['titre3']; ?>"><br>

<label for="titre">Titre 4:</label>
<input type="text" name="titre4" class="form-control" value="<?php echo $D['titre4']; ?>"><br>

<div id="additional-fields"></div>

<button type="button" id="add-field-btn" onclick="addField()" style="width: 180px; height: 41px; margin-left: 10px; background-color: #4285f4; color: white !important; border-radius: 20px;">Ajouter un champ</button></br></br>

<script>
    let fieldCount = 4;  // Compteur des champs déjà affichés (4 premiers)

    function addField() {
        if (fieldCount < 12) { // Maximum de 12 champs
            fieldCount++;
            const newField = document.createElement("div");
            newField.innerHTML = `
                <label for="titre">Titre ${fieldCount}:</label>
                <input type="text" name="titre${fieldCount}" class="form-control"><br>
            `;
            document.getElementById("additional-fields").appendChild(newField);
        }
        
        // Si tous les champs sont ajoutés, on masque le bouton
        if (fieldCount >= 12) {
            document.getElementById("add-field-btn").style.display = "none";
        }
    }
</script>




                                        <label for="description">Description 1:</label>
                                                <textarea name="description1" class="form-control" ><?php echo $D['descriptions1']; ?></textarea><br>

                                                <label for="description">Description 2:</label>
                                                <textarea name="description2" class="form-control" ><?php echo $D['descriptions2']; ?></textarea><br>

                                                <label for="description">Description 3:</label>
                                                <textarea name="description3" class="form-control" ><?php echo $D['descriptions3']; ?></textarea><br>

                                                <label for="description">Description 4:</label>
                                                <textarea name="description4" class="form-control" ><?php echo $D['descriptions4']; ?></textarea><br>

                                                <label for="path">Chemin 1 :</label>
                                                <input type="text" name="chemin1" class="form-control" value="<?php echo $D['chemin1']; ?>"><br>

                                                <label for="path">Chemin 2 :</label>
                                                <input type="text" name="chemin2" class="form-control" value="<?php echo $D['chemin2']; ?>"><br>

                                              
                                               
                                               

                                                <?php echo anchor("Googleads/campagne/".$client[0]['idclients'], 
                                                '<h6  style=" width: 200px; height: 41px; margin-left: 10px; background-color: #4285f4;color: white;  border-radius: 20px;" class="btn"">Valider votre annonce</h6><i class="button"></i>', 
                                                'data-edit="'.$client[0]['idclients'].'"'); ?>
											
                                            </div>
                                            </div>
        </div>
        <div class="col-md-8">
            
        <!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Annonce Maison Beneva</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            width: 50%;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
        }
        th {
            background-color: #4285f4;
            color: white;
            text-align: left;
        }
        td {
            background-color: #F4F8FB;
        }
        .header {
            font-weight: bold;
            color: #333;
            font-size: 18px;
            width: 35%;
        }
        .blue-cell {
            background-color: #4285f4;
            font-weight: bold;
            color: white;
            width: 10%;
        }
        .green-text {
            color: green;
        }
        .col {
            background-color: red;
        }
        /* Style for export button */
        .export-btn {
            margin: 20px 0;
            padding: 10px 20px;
            background-color: #4285f4;
            color: white;
            border: none;
            cursor: pointer;
        }
        /* Image style for logo */
        .logo-container {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }
        .logo-container img {
            width: 200px;
            padding-right: 20px;
        }
        .logo-container h1 {
            flex: 1;
            text-align: right;
        }
    </style>
    <!-- Include html2pdf.js CDN -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.9.2/html2pdf.bundle.js"></script>
</head>
<body>

    

    <div id="exportable-content" style="margin-top: 31px;">
    <label for="group-name">Preview</label>
        <div class="logo-container">
            <div style="flex: 1; padding-right: 20px;">
                <img src="<?php echo base_url(IMAGES_PATH."/logo/logo3.png"); ?>" style="width: 200px;">
            </div>
            <div style="flex: 1; text-align: right;">
                <h1><b>Annonce</b></h1>
            </div>
        </div>

        <!-- Contenu de l'annonce -->
        <?php foreach($search as $G): ?>
        <table id="exportable-table">
            <tr>
                <td class="blue-cell">Campagne</td>
                <td class="header" style="text-align: center;"><?php echo $G['nom_campagne']; ?></td>
            </tr>
            <tr>
                <td class="blue-cell">Groupe d'annonces</td>
                <td class="header" style="text-align: center;"><?php echo $G['nom_groupe']; ?></td>
            </tr>
            <tr>
                <td class="blue-cell">Titres</td>
                <td style="text-align: center;">
                    <?php echo implode('<br>', array_filter([$G['titre1'], $G['titre2'], $G['titre3'], $G['titre4'], $G['titre5'], $G['titre6'], $G['titre7'], $G['titre8'], $G['titre9'], $G['titre10'], $G['titre11'], $G['titre12']])); ?>
                </td>
            </tr>
            <tr>
                <td class="blue-cell">Descriptions</td>
                <td style="text-align: center;">
                <?php echo $G['descriptions1']; ?><br>
                <?php echo $G['descriptions2']; ?><br>
                <?php echo $G['descriptions3']; ?><br>
                <?php echo $G['descriptions4']; ?><br>
                </td>
            </tr>
            <tr>
                <td class="blue-cell">Chemin 1</td>
                <td style="text-align: center;"> <?php echo $G['chemin1']; ?></td>
            </tr>
            <tr>
                <td class="blue-cell">Chemin 2</td>
                <td style="text-align: center;"> <?php echo $G['chemin2']; ?></td>
            </tr>
            <tr>
                <td class="blue-cell">URL</td>
                <td style="text-align: center;"><a href="<?php echo $G['url_groupe_annonce']; ?>" target="_blank"><?php echo $G['url_groupe_annonce']; ?></a></td>
            </tr>

        </table>
        <button type="submit" class="btn btn-success" style="width: 180px; height: 41px; margin-left: 10px; background-color: #4285f4; color: white !important; border-radius: 20px;">Prévisualiser</button>
    </div> 

    </form>
<?php endforeach; ?>
</body>
</html>


        </div>
        </div>    