<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

This is the content of the main page
